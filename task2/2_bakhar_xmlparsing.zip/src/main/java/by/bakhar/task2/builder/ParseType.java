package by.bakhar.task2.builder;

public enum ParseType {
    DOM,
    SAX,
    STAX;
}
