package by.bakhar.task3.service;

import by.bakhar.task3.entity.Cone;

public interface CountSquareVolume {
    double countSquare(Cone cone);
    double countVolume(Cone cone);
}
