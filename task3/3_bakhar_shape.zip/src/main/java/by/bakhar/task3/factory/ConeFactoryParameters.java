package by.bakhar.task3.factory;

public class ConeFactoryParameters {
    public static final int NUMBER_OF_PARAMS = 7;
    private ConeFactoryParameters() {
    }
}
