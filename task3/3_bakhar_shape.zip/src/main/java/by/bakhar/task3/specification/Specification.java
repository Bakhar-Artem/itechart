package by.bakhar.task3.specification;

import by.bakhar.task3.entity.Cone;

public interface Specification {
    boolean specify(Cone cone);
}
