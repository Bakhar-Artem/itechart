package by.bakhar.task4.reader;

import java.io.IOException;

public interface TextReader {
    String readTextFromTxt(String filepath) throws IOException;
}
