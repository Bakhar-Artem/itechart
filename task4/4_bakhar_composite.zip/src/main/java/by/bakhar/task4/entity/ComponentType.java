package by.bakhar.task4.entity;

public enum ComponentType {
    TEXT,
    PARAGRAPH,
    SENTENCE,
    LEXEME,
    WORD,
    SYMBOl,
    PUNCTUATION;
}
